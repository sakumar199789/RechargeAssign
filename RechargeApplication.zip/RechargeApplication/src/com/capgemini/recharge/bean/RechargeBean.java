package com.capgemini.recharge.bean;

public class RechargeBean {
String customerName,planName;
int planId,planAmount,cusomerId;
long mobile;

public long getMobile() {
	return mobile;
}
public void setMobile(long mobile) {
	this.mobile = mobile;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getPlanName() {
	return planName;
}
public void setPlanName(String planName) {
	this.planName = planName;
}
public int getPlanId() {
	return planId;
}
public void setPlanId(int planId) {
	this.planId = planId;
}
public int getPlanAmount() {
	return planAmount;
}
public void setPlanAmount(int planAmount) {
	this.planAmount = planAmount;
}
public int getCusomerId() {
	return cusomerId;
}
public void setCusomerId(int cusomerId) {
	this.cusomerId = cusomerId;
}

}
