package com.capgemini.recharge.dao;

public interface IQueryMapper {
public static final String RECHARGE_AMOUNT="INSERT INTO customer VALUES(rec_seq.NEXTVAL,?,?,?,?)";
public static final String PLANS="SELECT * FROM plan";
public static final String PLAN_ID="SELECT planid FROM plan where planname=?";
}
