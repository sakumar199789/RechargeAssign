package com.capgemini.recharge.dao;

import java.util.ArrayList;

import com.capgemini.recharge.bean.RechargeBean;
import com.capgemini.recharge.exception.RechargeException;
public interface IRechargeDAO {
	public ArrayList<RechargeBean> getPlans() throws RechargeException;
	public void recharge(RechargeBean recharge) throws RechargeException;
}
