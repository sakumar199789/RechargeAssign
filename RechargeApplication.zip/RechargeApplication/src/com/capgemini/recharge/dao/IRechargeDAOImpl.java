package com.capgemini.recharge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import com.capgemini.recharge.util.DBConnection;
import com.capgemini.recharge.bean.RechargeBean;
import com.capgemini.recharge.exception.RechargeException;

public class IRechargeDAOImpl implements IRechargeDAO{

	@Override
	public ArrayList<RechargeBean> getPlans() throws RechargeException {
		PreparedStatement stmt=null;
		boolean temp=false;
		ResultSet rs=null;
		ArrayList<RechargeBean> planList=new ArrayList();
		try{
			Connection conn=DBConnection.getConnection();
			stmt=conn.prepareStatement(IQueryMapper.PLANS);
			ResultSet result=stmt.executeQuery();
			while(result.next()) {
				RechargeBean recharge=new RechargeBean();
				recharge.setPlanId(result.getInt(1));
				recharge.setPlanName(result.getString(2));
				recharge.setPlanAmount(result.getInt(3));
			planList.add(recharge);
			}
		
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return planList;
	}

	@Override
	public void recharge(RechargeBean recharge) throws RechargeException {
		PreparedStatement stmt=null,stmt1;
		boolean temp=false;
		ResultSet rs=null,rs1;
	
		try{
			Connection conn=DBConnection.getConnection();
			stmt1=conn.prepareStatement(IQueryMapper.PLAN_ID);
			stmt1.setString(1, recharge.getPlanName());
			rs1=stmt1.executeQuery();
			rs1.next();
			stmt=conn.prepareStatement(IQueryMapper.RECHARGE_AMOUNT);
			stmt.setString(1, recharge.getCustomerName());
			stmt.setLong(2,recharge.getMobile());
			stmt.setString(3, recharge.getPlanName());
			stmt.setInt(4, rs1.getInt(1));
			
			stmt.executeUpdate();
			
			}
		
		
		catch(Exception e) {
			System.out.println(e);
		}
		
		
	}
	
	
}
