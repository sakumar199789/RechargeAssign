package com.capgemini.recharge.exception;

public class RechargeException extends Exception{
String excep;
	public RechargeException(String msg){
		excep=msg;
	}
	public String toString() {
		return excep;
	}
}
