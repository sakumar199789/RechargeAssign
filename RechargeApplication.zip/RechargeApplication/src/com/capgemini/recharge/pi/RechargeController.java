package com.capgemini.recharge.pi;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.recharge.bean.RechargeBean;
import com.capgemini.recharge.exception.RechargeException;
import com.capgemini.recharge.service.IRecharge;
import com.capgemini.recharge.service.RechargeImpl;

/**
 * Servlet implementation class RechargeController
 */
@WebServlet("/RechargeController")
public class RechargeController extends HttpServlet {
	IRecharge ie=new RechargeImpl();
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RechargeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	response.getWriter().println("In Recharge Controller");
	try {	
	switch(request.getParameter("action")) {
		case "rechargeform":
					ArrayList<RechargeBean> planList=ie.getPlans();
					request.setAttribute("planList", planList);
					request.getRequestDispatcher("RechargeForm.jsp").forward(request, response);
		case "Recharge":
				RechargeBean recharge=new RechargeBean();
				recharge.setCustomerName(request.getParameter("name"));
				recharge.setPlanName(request.getParameter("plan"));
				recharge.setMobile(Long.parseLong(request.getParameter("mobile")));
				ie.recharge(recharge);
				
		}
	}
	
	catch(RechargeException r) {
		System.out.println(r);
	}
	

}
}
