package com.capgemini.recharge.service;

import java.util.ArrayList;

import com.capgemini.recharge.bean.RechargeBean;
import com.capgemini.recharge.exception.RechargeException;

public interface IRecharge {

	public ArrayList<RechargeBean> getPlans() throws RechargeException;
	public void recharge(RechargeBean recharge) throws RechargeException;
}
