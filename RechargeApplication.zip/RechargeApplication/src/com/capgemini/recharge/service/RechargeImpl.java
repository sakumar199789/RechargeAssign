package com.capgemini.recharge.service;

import java.util.ArrayList;

import com.capgemini.recharge.bean.RechargeBean;
import com.capgemini.recharge.dao.IRechargeDAO;
import com.capgemini.recharge.dao.IRechargeDAOImpl;
import com.capgemini.recharge.exception.RechargeException;

public class RechargeImpl implements IRecharge{
public ArrayList<RechargeBean> getPlans() throws RechargeException{
	IRechargeDAO ie=new IRechargeDAOImpl();
	return ie.getPlans();
	
}

@Override
public void recharge(RechargeBean recharge) throws RechargeException {
	IRechargeDAO ie=new IRechargeDAOImpl();
	ie.recharge(recharge);		
	
}
}
